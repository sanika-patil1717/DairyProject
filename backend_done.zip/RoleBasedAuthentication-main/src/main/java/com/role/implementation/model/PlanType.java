package com.role.implementation.model;


public enum PlanType {

    FREE,
    MONTHLY,
    ANNUALLY
}

